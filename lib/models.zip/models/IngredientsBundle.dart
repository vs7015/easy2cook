import 'package:flutter/material.dart';

class IngredientsBundle {
  final String name;

  IngredientsBundle({required this.name});
}
