class FUser {
  final String? uid;

  FUser({this.uid});
}
